# Netflix Code Hub

No-login Netflix code dashboard for family use.
Shows sign-in codes, household codes & update links from the last 15 minutes.

---

## Folder Structure

```
netflix-hub/
├── server.js          ← Backend (Node.js + IMAP)
├── package.json
├── railway.json
└── public/
    └── index.html     ← Frontend
```

---

## Deploy on Railway (Step by Step)

### Step 1 — Get Gmail App Password
1. Go to https://myaccount.google.com/security
2. Enable 2-Step Verification
3. Search "App Passwords" → Create new → Name it "Netflix Hub"
4. Copy the 16-character password (remove spaces)

### Step 2 — Upload to GitHub
1. Go to https://github.com → New repository → Name it "netflix-hub"
2. Upload all files keeping the folder structure above
3. Commit

### Step 3 — Deploy on Railway
1. Go to https://railway.app → Login with GitHub
2. Click "New Project" → "Deploy from GitHub repo"
3. Select your "netflix-hub" repo
4. Click "Add Variables" and add:
   - GMAIL_USER = your-master-gmail@gmail.com
   - GMAIL_PASS = your16charapppassword
5. Railway will auto-deploy. Copy your URL (e.g. https://netflix-hub.up.railway.app)

### Step 4 — Share with family
Just send them the Railway URL. No login needed!
They type their Netflix email → get their code instantly.

---

## How It Works
- Backend connects to YOUR Gmail via IMAP (app password)
- Only fetches Netflix emails from the last 15 minutes
- Filters by the email address the user types
- Nothing is stored — fresh fetch every time
